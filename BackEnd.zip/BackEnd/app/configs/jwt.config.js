var config = {
    'secret': 'js12sj324'
  };

module.exports = config;