module.exports = {
    secret: "brief-secret-key",
    user: "brieftest10@gmail.com", 
    pass: "briefbrief", 
};