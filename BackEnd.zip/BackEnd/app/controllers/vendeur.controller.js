const Vendeur = require('../models/model.vendeur');
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const config = require("../configs/jwt.config")
const { body, validationResult } = require('express-validator');
const util = require("util");
const multer = require("multer");
const maxSize = 2 * 1024 * 1024;



exports.registerVendeur =  async (req, res) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }


    let storage = multer.diskStorage({
        destination: (req, file, cb) => {
          // @ts-ignore
          cb(null, __basedir + "/app/upload/docs");
        },
        filename: (req, file, cb) => {
          console.log(file.originalname);
          cb(null, file.originalname);
        },
      });
    
      let uploadFile = multer({
        storage: storage,
        limits: {
          fileSize: maxSize
        },
      }).single("file");
    
      let uploadFileMiddleware = util.promisify(uploadFile);
    
      try {
        
                await uploadFileMiddleware(req, res);
                if (req.file == undefined) {
                  return res.status(400).send({ message: "Please upload a file!" });
                   }

                let vendeurPush = new Vendeur({
                    nom: req.body.nom,
                    prenom: req.body.prenom,
                    email: req.body.email,
                    password: bcrypt.hashSync(req.body.password, 10),
                    phone: req.body.phone,
                    fichierAdministratif: req.file.originalname
                   
                })
                  
                vendeurPush.save()
                    .then(() => res.json({notification : "Account registred .. status : Pending .. !" }))
                    .catch((err) => res.json(err))
 
            
       
    }
    catch (err) {
        console.log(err);
    
        if (err.code == "LIMIT_FILE_SIZE") {
          return res.status(500).send({
            message: "File size cannot be larger than 2MB!",
          });
        }
    
        res.status(500).send({
          message: `Could not upload the file: ${req.file.originalname}. ${err}`,
        });
      }
    
    // Vendeur.findOne({ email: req.body.email })
    //     .then((vendeur) => {
    //         if (vendeur == null) {
    //             vendeurPush.save()
    //                 .then(() => res.json({notification : "Account registred .. Pending .. !" }))
    //                 .catch((err) => res.json(err))
 
    //         }
    //         else {
    //             res.json("email already exist !");
    //         }
    //     })
    //     .catch((err) => res.json(err))
    
}